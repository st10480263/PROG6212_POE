﻿namespace RaceDayApp.Services
{
    public interface IBlobService
    {
        Task<string> UploadBlobAsync(Stream content, string fileName, string contentType);
    }
}