﻿namespace POE_ST10480263.Services
{
    public interface IApiService
    {
        Task<TResponse?> GetAsync<TResponse>(string endpoint);
        Task<TResponse?> PostAsync<TRequest, TResponse>(string endpoint, TRequest data);
        Task<bool> PostAsync<TRequest>(string endpoint, TRequest data);
        Task<bool> PostMultipartAsync(string endpoint, MultipartFormDataContent content);
        Task<bool> DeleteAsync(string endpoint);
    }
}
