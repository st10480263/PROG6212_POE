﻿using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;

namespace RaceDayApp.Services
{
    public class BlobService : IBlobService
    {
        private readonly BlobServiceClient _blobServiceClient;
        private const string ContainerName = "race-banners";

        public BlobService(IConfiguration configuration)
        {
            var connectionString = configuration.GetConnectionString("AzureBlobStorage")
                                   ?? "UseDevelopmentStorage=true";
            _blobServiceClient = new BlobServiceClient(connectionString);
        }

        public async Task<string> UploadBlobAsync(Stream content, string fileName, string contentType)
        {
            var containerClient = _blobServiceClient.GetBlobContainerClient(ContainerName);
            await containerClient.CreateIfNotExistsAsync(PublicAccessType.Blob);

            var blobFileName = $"{Guid.NewGuid()}_{Path.GetFileName(fileName)}";
            var blobClient = containerClient.GetBlobClient(blobFileName);

            var blobHeaders = new BlobHttpHeaders { ContentType = contentType };
            await blobClient.UploadAsync(content, new BlobUploadOptions { HttpHeaders = blobHeaders });

            return blobClient.Uri.ToString();
        }
    }
}