﻿using Microsoft.AspNetCore.Mvc;

using POE_ST10480263.Services;
using POE_ST10480263.Web.Models;
using RaceDay.Web.Filters;

namespace POE_ST10480263.Controllers
{
    [SessionAuthorize("Organiser")]
    public class OrganiserController : Controller
    {
        private readonly IApiService _apiService;

        public OrganiserController(IApiService apiService)
        {
            _apiService = apiService;
        }

        [HttpGet]
        public async Task<IActionResult> Dashboard()
        {
            var data = await _apiService.GetAsync<OrganiserDashboardViewModel>("api/organiser/dashboard");
            return View(data ?? new OrganiserDashboardViewModel());
        }

        [HttpGet]
        public async Task<IActionResult> Events()
        {
            var list = await _apiService.GetAsync<List<EventItemViewModel>>("api/events/my-events");
            return View(list ?? new List<EventItemViewModel>());
        }

        [HttpGet]
        public IActionResult CreateEvent() => View(new EventFormViewModel());

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreateEvent(EventFormViewModel model)
        {
            if (!ModelState.IsValid) return View(model);

            using var form = new MultipartFormDataContent();
            form.Add(new StringContent(model.EventName), "EventName");
            form.Add(new StringContent(model.Description), "Description");
            form.Add(new StringContent(model.EventDate.ToString("yyyy-MM-dd")), "EventDate");
            form.Add(new StringContent(model.Location), "Location");
            form.Add(new StringContent(model.Distance), "Distance");
            form.Add(new StringContent(model.EventType), "EventType");

            if (model.BannerFile != null)
            {
                var stream = model.BannerFile.OpenReadStream();
                form.Add(new StreamContent(stream), "bannerFile", model.BannerFile.FileName);
            }

            var success = await _apiService.PostMultipartAsync("api/events", form);
            if (success) return RedirectToAction(nameof(Events));

            ModelState.AddModelError(string.Empty, "Error creating event via API.");
            return View(model);
        }

        [HttpGet]
        public async Task<IActionResult> Categories(string eventId)
        {
            ViewBag.EventId = eventId;
            var categories = await _apiService.GetAsync<List<CategoryItemViewModel>>($"api/events/{eventId}/categories");
            return View(categories ?? new List<CategoryItemViewModel>());
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AddCategory(string eventId, CategoryItemViewModel model)
        {
            if (!ModelState.IsValid) return RedirectToAction(nameof(Categories), new { eventId });

            model.EventID = eventId;
            await _apiService.PostAsync($"api/events/{eventId}/categories", model);
            return RedirectToAction(nameof(Categories), new { eventId });
        }

        [HttpGet]
        public async Task<IActionResult> Enrolments(string eventId)
        {
            ViewBag.EventId = eventId;
            var enrolments = await _apiService.GetAsync<List<EventEnrolmentItemViewModel>>($"api/events/{eventId}/enrolments");
            return View(enrolments ?? new List<EventEnrolmentItemViewModel>());
        }

        [HttpGet]
        public IActionResult RecordResult(string eventId, string enrolmentId)
        {
            return View(new RecordResultViewModel { EventID = eventId, EnrolmentID = enrolmentId });
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> RecordResult(RecordResultViewModel model)
        {
            if (!ModelState.IsValid) return View(model);

            var success = await _apiService.PostAsync("api/results", model);
            if (success)
            {
                return RedirectToAction(nameof(Enrolments), new { eventId = model.EventID });
            }

            ModelState.AddModelError(string.Empty, "Failed to capture results.");
            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteEvent(string id)
        {
            await _apiService.DeleteAsync($"api/events/{id}");
            return RedirectToAction(nameof(Events));
        }
    }
}