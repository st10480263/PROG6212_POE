﻿using Microsoft.AspNetCore.Mvc;
using POE_ST10480263.Services; 
using POE_ST10480263.Web.Models;

namespace POE_ST10480263.Controllers
{
    public class AccountController : Controller
    {
        private readonly IApiService _apiService;

        public AccountController(IApiService apiService)
        {
            _apiService = apiService;
        }

        [HttpGet]
        public IActionResult Login() => View();

        [HttpPost]
        public async Task<IActionResult> Login(LoginViewModel model)
        {
            if (!ModelState.IsValid) return View(model);

            var response = await _apiService.PostAsync<LoginViewModel, AuthResponseViewModel>("api/auth/login", model);

            if (response != null && !string.IsNullOrEmpty(response.Token))
            {
                HttpContext.Session.SetString("JWToken", response.Token);
                HttpContext.Session.SetString("UserRole", response.Role);
                HttpContext.Session.SetString("UserName", response.FullName);

                if (response.Role.Equals("Organiser", StringComparison.OrdinalIgnoreCase))
                {
                    return RedirectToAction("Dashboard", "Organiser");
                }

                return RedirectToAction("Index", "Events");
            }

            ModelState.AddModelError(string.Empty, "Invalid login credentials.");
            return View(model);
        }

        [HttpGet]
        public IActionResult Register()
        {
            return View();
        }

        // 2. POST method: processes the form
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Register(RegisterViewModel model)
        {
            if (!ModelState.IsValid) return View(model);

            var client = HttpContext.RequestServices.GetRequiredService<IHttpClientFactory>().CreateClient("RaceDayApi");

            var apiPayload = new
            {
                UserID = Guid.NewGuid().ToString(),
                FullName = model.FullName,
                Email = model.Email,
                Password = model.Password,
                Role = model.Role,
                PhoneNumber = model.PhoneNumber
            };

            var jsonContent = new StringContent(
                System.Text.Json.JsonSerializer.Serialize(apiPayload),
                System.Text.Encoding.UTF8,
                "application/json"
            );

            var response = await client.PostAsync("api/auth/register", jsonContent);

            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction("Login");
            }

            var errorBody = await response.Content.ReadAsStringAsync();
            ModelState.AddModelError(string.Empty, string.IsNullOrWhiteSpace(errorBody)
                ? $"Registration failed with status: {response.StatusCode}"
                : errorBody.Trim('"'));

            return View(model);
        }

        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Login");
        }
    }
}
