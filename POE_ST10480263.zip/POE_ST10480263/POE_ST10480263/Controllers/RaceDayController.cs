﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using RaceDayApp.Services;
using RaceDayData.Data;
using RaceDayModel.Models;
using RaceDayModel.Models.RaceDayModel;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace RaceDayApp.Controllers;

[ApiController]
public class RaceDayController : ControllerBase
{
    private readonly RaceDayDataContext _context;
    private readonly IBlobService _blobService;
    private const string SecretKey = "RaceDaySuperSecretKeyThatIsAtLeast32CharactersLong!";

    public RaceDayController(RaceDayDataContext context, IBlobService blobService)
    {
        _context = context;
        _blobService = blobService;
    }

    // ==========================================
    // 1. AUTHENTICATION ENDPOINTS
    // ==========================================

    [HttpPost("api/auth/register")]
    public IActionResult Register([FromBody] Users newUser)
    {
        if (_context.Users.Any(u => u.Email == newUser.Email))
            return Conflict("Email already registered.");

        if (string.IsNullOrEmpty(newUser.UserID))
            newUser.UserID = Guid.NewGuid().ToString();

        _context.Users.Add(newUser);
        _context.SaveChanges();

        var token = CreateJwtToken(newUser);
        return StatusCode(201, new
        {
            message = "User registered successfully",
            token,
            role = newUser.Role,
            fullName = newUser.FullName
        });
    }

    [HttpPost("api/auth/login")]
    public IActionResult Login([FromBody] RaceDayModel.Models.Login request)
    {
        var user = _context.Users.FirstOrDefault(u => u.Email == request.Email && u.Password == request.Password);
        if (user == null)
            return Unauthorized("Invalid email or password.");

        var token = CreateJwtToken(user);
        return Ok(new
        {
            token,
            role = user.Role,
            fullName = user.FullName,
            userId = user.UserID
        });
    }

    // ==========================================
    // 2. USER PROFILE ENDPOINTS
    // ==========================================

    [Authorize]
    [HttpGet("api/users/profile")]
    public IActionResult GetProfile()
    {
        var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
        var user = _context.Users.Find(userId);
        if (user == null)
            return NotFound("User profile not found.");

        return Ok(user);
    }

    [Authorize]
    [HttpPut("api/users/profile")]
    public IActionResult UpdateProfile([FromBody] UpdateProfileRequest request)
    {
        var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
        var user = _context.Users.Find(userId);
        if (user == null)
            return NotFound("User profile not found.");

        user.PhoneNumber = request.Phone;
        _context.SaveChanges();

        return Ok(user);
    }

    [Authorize]
    [HttpPost("api/users/profile-picture")]
    public async Task<IActionResult> UploadProfilePicture(IFormFile file)
    {
        if (file == null || file.Length == 0)
            return BadRequest("No file uploaded.");

        var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
        var user = _context.Users.Find(userId);
        if (user == null)
            return NotFound("User not found.");

        using var stream = file.OpenReadStream();
        var imageUrl = await _blobService.UploadBlobAsync(stream, file.FileName, file.ContentType);

        user.ProfilePictureUrl = imageUrl;
        _context.SaveChanges();

        return Ok(new { imageUrl });
    }

    // ==========================================
    // 3. EVENT ENDPOINTS (Organiser & Participant)
    // ==========================================

    [HttpGet("api/events")]
    public IActionResult GetEvents([FromQuery] string? eventType, [FromQuery] DateOnly? date)
    {
        var query = _context.Events.AsQueryable();

        if (!string.IsNullOrWhiteSpace(eventType))
            query = query.Where(e => e.EventType == eventType);

        if (date.HasValue)
            query = query.Where(e => e.EventDate == date.Value);

        return Ok(query.OrderBy(e => e.EventDate).ToList());
    }

    [HttpGet("api/events/{id}")]
    public IActionResult GetEventById(string id)
    {
        var ev = _context.Events.Find(id);
        if (ev == null) return NotFound("Event not found.");
        return Ok(ev);
    }

    [Authorize(Roles = "Organiser")]
    [HttpGet("api/events/my-events")]
    public IActionResult GetMyOrganisedEvents()
    {
        var organiserId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
        var myEvents = _context.Events.Where(e => e.OrganiserID == organiserId).ToList();
        return Ok(myEvents);
    }

    [Authorize(Roles = "Organiser")]
    [HttpPost("api/events")]
    public async Task<IActionResult> CreateEvent([FromForm] Events newEvent, IFormFile? bannerFile)
    {
        var organiserId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
        newEvent.OrganiserID = organiserId ?? string.Empty;

        if (string.IsNullOrEmpty(newEvent.EventID))
            newEvent.EventID = Guid.NewGuid().ToString();

        // Upload banner to Azure Blob Storage if provided
        if (bannerFile != null && bannerFile.Length > 0)
        {
            using var stream = bannerFile.OpenReadStream();
            newEvent.BannerImageUrl = await _blobService.UploadBlobAsync(stream, bannerFile.FileName, bannerFile.ContentType);
        }

        _context.Events.Add(newEvent);
        _context.SaveChanges();

        return StatusCode(201, newEvent);
    }

    [Authorize(Roles = "Organiser")]
    [HttpPut("api/events/{id}")]
    public async Task<IActionResult> UpdateEvent(string id, [FromForm] Events updatedEvent, IFormFile? bannerFile)
    {
        var ev = _context.Events.Find(id);
        if (ev == null) return NotFound("Event not found.");

        ev.EventName = updatedEvent.EventName;
        ev.Description = updatedEvent.Description;
        ev.EventDate = updatedEvent.EventDate;
        ev.Location = updatedEvent.Location;
        ev.Distance = updatedEvent.Distance;
        ev.EventType = updatedEvent.EventType;

        if (bannerFile != null && bannerFile.Length > 0)
        {
            using var stream = bannerFile.OpenReadStream();
            ev.BannerImageUrl = await _blobService.UploadBlobAsync(stream, bannerFile.FileName, bannerFile.ContentType);
        }

        _context.SaveChanges();
        return Ok(ev);
    }

    [Authorize(Roles = "Organiser")]
    [HttpDelete("api/events/{id}")]
    public IActionResult DeleteEvent(string id)
    {
        var ev = _context.Events.Find(id);
        if (ev == null) return NotFound("Event not found.");

        _context.Events.Remove(ev);
        _context.SaveChanges();
        return NoContent();
    }

    [Authorize(Roles = "Organiser")]
    [HttpGet("api/organiser/dashboard")]
    public IActionResult GetDashboardSummary()
    {
        var organiserId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
        var myEvents = _context.Events.Where(e => e.OrganiserID == organiserId).ToList();
        var myEventIds = myEvents.Select(e => e.EventID).ToList();

        var totalEnrolments = _context.Enrolments.Count(en => myEventIds.Contains(en.EventID));
        var today = DateOnly.FromDateTime(DateTime.Today);
        var upcomingEvents = myEvents.Where(e => e.EventDate >= today).OrderBy(e => e.EventDate).ToList();

        return Ok(new OrganiserDashboardDto
        {
            TotalEvents = myEvents.Count,
            TotalEnrolments = totalEnrolments,
            UpcomingEvents = upcomingEvents
        });
    }

    // ==========================================
    // 4. CATEGORIES ENDPOINTS
    // ==========================================

    [Authorize(Roles = "Organiser")]
    [HttpPost("api/events/{id}/categories")]
    public IActionResult AddCategory(string id, [FromBody] Categories newCategory)
    {
        newCategory.EventID = id;
        if (string.IsNullOrEmpty(newCategory.CategoryID))
            newCategory.CategoryID = Guid.NewGuid().ToString();

        _context.Categories.Add(newCategory);
        _context.SaveChanges();

        return StatusCode(201, newCategory);
    }

    [HttpGet("api/events/{id}/categories")]
    public IActionResult GetCategoriesForEvent(string id)
    {
        var categories = _context.Categories.Where(c => c.EventID == id).ToList();
        return Ok(categories);
    }

    // ==========================================
    // 5. ENROLMENT ENDPOINTS
    // ==========================================

    [Authorize(Roles = "Participant")]
    [HttpPost("api/enrolments")]
    public IActionResult Enrol([FromBody] EnrolmentRequest request)
    {
        var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;

        bool alreadyEnrolled = _context.Enrolments.Any(e => e.ParticipantID == userId && e.EventID == request.EventID);
        if (alreadyEnrolled)
            return Conflict("Already entered in this event.");

        var enrolment = new Enrolments
        {
            EnrolmentID = Guid.NewGuid().ToString(),
            ParticipantID = userId ?? string.Empty,
            EventID = request.EventID,
            CategoryID = request.CategoryID,
            RegistrationDate = DateOnly.FromDateTime(DateTime.Today),
            Status = "Confirmed"
        };

        _context.Enrolments.Add(enrolment);
        _context.SaveChanges();

        return StatusCode(201, enrolment);
    }

    [Authorize(Roles = "Participant")]
    [HttpGet("api/enrolments/my-entries")]
    public IActionResult GetMyEntries()
    {
        var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
        var myEnrolments = _context.Enrolments.Where(e => e.ParticipantID == userId).ToList();
        return Ok(myEnrolments);
    }

    [Authorize(Roles = "Organiser")]
    [HttpGet("api/events/{eventId}/enrolments")]
    public IActionResult GetEnrolmentsForEvent(string eventId)
    {
        var enrolments = (from en in _context.Enrolments
                          where en.EventID == eventId
                          join u in _context.Users on en.ParticipantID equals u.UserID into userGroup
                          from user in userGroup.DefaultIfEmpty()
                          join c in _context.Categories on en.CategoryID equals c.CategoryID into catGroup
                          from cat in catGroup.DefaultIfEmpty()
                          select new
                          {
                              en.EnrolmentID,
                              en.EventID,
                              en.Status,
                              en.RegistrationDate,
                              ParticipantName = user != null ? user.FullName : "Unknown",
                              CategoryName = cat != null ? cat.CategoryName : "Unassigned"
                          }).ToList();

        return Ok(enrolments);
    }

    // ==========================================
    // 6. RESULTS ENDPOINTS
    // ==========================================

    [Authorize(Roles = "Organiser")]
    [HttpPost("api/results")]
    public IActionResult RecordResult([FromBody] RaceDayModel.Models.Results result)
    {
        if (result == null)
            return BadRequest("Result payload cannot be null.");

        if (string.IsNullOrEmpty(result.ResultsID))
            result.ResultsID = Guid.NewGuid().ToString();

        _context.Results.Add(result);
        _context.SaveChanges();

        return StatusCode(201, result);
    }

    [HttpGet("api/results/event/{eventId}")]
    public IActionResult GetLeaderboard(string eventId)
    {
        var enrolmentIds = _context.Enrolments
            .Where(e => e.EventID == eventId)
            .Select(e => e.EnrolmentID)
            .ToList();

        var leaderboard = _context.Results
            .Where(r => enrolmentIds.Contains(r.EnrolmentID))
            .OrderBy(r => r.Position)
            .ToList();

        return Ok(leaderboard);
    }

    [Authorize(Roles = "Participant")]
    [HttpGet("api/results/my-history")]
    public IActionResult GetMyHistory()
    {
        var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;

        var myEnrolments = _context.Enrolments
            .Where(e => e.ParticipantID == userId)
            .ToList();

        var myEnrolmentIds = myEnrolments.Select(e => e.EnrolmentID).ToList();

        var history = (from r in _context.Results
                       where myEnrolmentIds.Contains(r.EnrolmentID)
                       join en in _context.Enrolments on r.EnrolmentID equals en.EnrolmentID
                       join ev in _context.Events on en.EventID equals ev.EventID into evGroup
                       from evItem in evGroup.DefaultIfEmpty()
                       join cat in _context.Categories on en.CategoryID equals cat.CategoryID into catGroup
                       from catItem in catGroup.DefaultIfEmpty()
                       select new
                       {
                           r.ResultsID,
                           EventName = evItem != null ? evItem.EventName : "Event",
                           EventDate = evItem != null ? evItem.EventDate : default,
                           CategoryName = catItem != null ? catItem.CategoryName : "Category",
                           r.FinishTime,
                           r.Position,
                           r.TotalFinishers,
                           r.Status
                       }).ToList();

        return Ok(history);
    }

    // ==========================================
    // TOKEN GENERATOR HELPER
    // ==========================================

    private string CreateJwtToken(Users user)
    {
        var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(SecretKey));
        var token = new JwtSecurityToken(
            claims: new[]
            {
                new Claim(ClaimTypes.NameIdentifier, user.UserID),
                new Claim(ClaimTypes.Role, user.Role),
                new Claim(ClaimTypes.Email, user.Email),
                new Claim("FullName", user.FullName)
            },
            expires: DateTime.UtcNow.AddHours(4),
            signingCredentials: new SigningCredentials(key, SecurityAlgorithms.HmacSha256)
        );

        return new JwtSecurityTokenHandler().WriteToken(token);
    }
}