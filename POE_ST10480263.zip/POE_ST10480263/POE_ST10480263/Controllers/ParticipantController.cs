﻿using Microsoft.AspNetCore.Mvc;

using POE_ST10480263.Services;
using POE_ST10480263.Web.Models;
using RaceDay.Web.Filters;

namespace POE_ST10480263.Controllers
{
    public class ParticipantController : Controller
    {
        private readonly IApiService _apiService;

        public ParticipantController(IApiService apiService)
        {
            _apiService = apiService;
        }

        // 1. Home page: Upcoming events with filtering (Available to public/logged in)
        [HttpGet]
        public async Task<IActionResult> Index(string? eventType, string? date)
        {
            var endpoint = "api/events";
            var queryParams = new List<string>();

            if (!string.IsNullOrEmpty(eventType)) queryParams.Add($"eventType={Uri.EscapeDataString(eventType)}");
            if (!string.IsNullOrEmpty(date)) queryParams.Add($"date={date}");

            if (queryParams.Any()) endpoint += "?" + string.Join("&", queryParams);

            var events = await _apiService.GetAsync<List<EventItemViewModel>>(endpoint);
            ViewBag.SelectedType = eventType;
            return View(events ?? new List<EventItemViewModel>());
        }

        // 2. Full Event details & category selection
        [HttpGet]
        public async Task<IActionResult> Details(string id)
        {
            var ev = await _apiService.GetAsync<EventItemViewModel>($"api/events/{id}");
            if (ev == null) return NotFound();

            var categories = await _apiService.GetAsync<List<CategoryItemViewModel>>($"api/events/{id}/categories");

            var model = new ParticipantEventDetailViewModel
            {
                Event = ev,
                Categories = categories ?? new List<CategoryItemViewModel>()
            };

            return View(model);
        }

        // 3. One-click Enrolment (Protected)
        [HttpPost]
        [SessionAuthorize("Participant")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Enrol(string eventId, string categoryId)
        {
            var payload = new { EventID = eventId, CategoryID = categoryId };
            var response = await _apiService.PostAsync("api/enrolments", payload);

            if (response)
            {
                TempData["SuccessMessage"] = "Successfully enrolled in the event!";
                return RedirectToAction(nameof(MyRegistrations));
            }

            TempData["ErrorMessage"] = "Could not enrol. You may already be registered.";
            return RedirectToAction(nameof(Details), new { id = eventId });
        }

        // 4. Personal View of Registered Events
        [HttpGet]
        [SessionAuthorize("Participant")]
        public async Task<IActionResult> MyRegistrations()
        {
            var myEntries = await _apiService.GetAsync<List<ParticipantEnrolmentHistoryViewModel>>("api/enrolments/my-entries");
            return View(myEntries ?? new List<ParticipantEnrolmentHistoryViewModel>());
        }

        // 5. My Results page
        [HttpGet]
        [SessionAuthorize("Participant")]
        public async Task<IActionResult> MyResults()
        {
            var results = await _apiService.GetAsync<List<ParticipantResultHistoryViewModel>>("api/results/my-history");
            return View(results ?? new List<ParticipantResultHistoryViewModel>());
        }

        // 6. Profile & Picture Upload
        [HttpGet]
        [SessionAuthorize("Participant")]
        public async Task<IActionResult> Profile()
        {
            var profile = await _apiService.GetAsync<ParticipantProfileViewModel>("api/users/profile");
            return View(profile ?? new ParticipantProfileViewModel());
        }

        [HttpPost]
        [SessionAuthorize("Participant")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Profile(ParticipantProfileViewModel model)
        {
            if (model.ProfilePicture != null)
            {
                using var form = new MultipartFormDataContent();
                var stream = model.ProfilePicture.OpenReadStream();
                form.Add(new StreamContent(stream), "file", model.ProfilePicture.FileName);
                await _apiService.PostMultipartAsync("api/users/profile-picture", form);
            }

            return RedirectToAction(nameof(Profile));
        }
    }
}