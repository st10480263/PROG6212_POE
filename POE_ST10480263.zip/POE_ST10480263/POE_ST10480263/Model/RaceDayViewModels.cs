﻿using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Http;

namespace POE_ST10480263.Web.Models
{
    // --- ORGANISER MODELS ---
    public class OrganiserDashboardViewModel
    {
        public int TotalEvents { get; set; }
        public int TotalEnrolments { get; set; }
        public List<EventItemViewModel> UpcomingEvents { get; set; } = new();
    }

    public class EventItemViewModel
    {
        public string EventID { get; set; } = string.Empty;
        public string EventName { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public DateOnly EventDate { get; set; }
        public string Location { get; set; } = string.Empty;
        public string Distance { get; set; } = string.Empty;
        public string EventType { get; set; } = string.Empty;
        public string? BannerImageUrl { get; set; }
        public List<CategoryItemViewModel> Categories { get; set; } = new();
    }

    public class EventFormViewModel
    {
        public string? EventID { get; set; }

        [Required(ErrorMessage = "Event name is required.")]
        public string EventName { get; set; } = string.Empty;

        [Required(ErrorMessage = "Description is required.")]
        public string Description { get; set; } = string.Empty;

        [Required(ErrorMessage = "Date is required.")]
        public DateOnly EventDate { get; set; } = DateOnly.FromDateTime(DateTime.Today.AddDays(7));

        [Required(ErrorMessage = "Location is required.")]
        public string Location { get; set; } = string.Empty;

        [Required(ErrorMessage = "Distance is required.")]
        public string Distance { get; set; } = string.Empty;

        [Required(ErrorMessage = "Event type is required.")]
        public string EventType { get; set; } = "Running";

        public IFormFile? BannerFile { get; set; }
        public string? ExistingBannerUrl { get; set; }
    }

    public class CategoryItemViewModel
    {
        public string CategoryID { get; set; } = string.Empty;
        public string EventID { get; set; } = string.Empty;
        [Required]
        public string CategoryName { get; set; } = string.Empty;
        [Required]
        public string Distance { get; set; } = string.Empty;
        public string Country { get; set; } = string.Empty;
    }

    public class EventEnrolmentItemViewModel
    {
        public string EnrolmentID { get; set; } = string.Empty;
        public string EventID { get; set; } = string.Empty;
        public string ParticipantName { get; set; } = string.Empty;
        public string CategoryName { get; set; } = string.Empty;
        public DateOnly RegistrationDate { get; set; }
        public string Status { get; set; } = "Confirmed";
    }

    public class RecordResultViewModel
    {
        public string EventID { get; set; } = string.Empty;

        [Required]
        public string EnrolmentID { get; set; } = string.Empty;

        [Required(ErrorMessage = "Finish time is required (e.g., 01:24:35).")]
        public string FinishTime { get; set; } = string.Empty;

        [Required(ErrorMessage = "Finishing position is required.")]
        public string Position { get; set; } = string.Empty;

        [Required(ErrorMessage = "Total finishers count is required.")]
        public string TotalFinishers { get; set; } = string.Empty;

        public string Status { get; set; } = "Finished";
    }

    // --- PARTICIPANT MODELS ---
    public class ParticipantEventDetailViewModel
    {
        public EventItemViewModel Event { get; set; } = new();
        public List<CategoryItemViewModel> Categories { get; set; } = new();
        public string? SelectedCategoryID { get; set; }
        public bool IsAlreadyEnrolled { get; set; }
    }

    public class ParticipantEnrolmentHistoryViewModel
    {
        public string EnrolmentID { get; set; } = string.Empty;
        public string EventName { get; set; } = string.Empty;
        public DateOnly EventDate { get; set; }
        public string CategoryName { get; set; } = string.Empty;
        public string Status { get; set; } = "Confirmed";
    }

    public class ParticipantResultHistoryViewModel
    {
        public string ResultsID { get; set; } = string.Empty;
        public string EventName { get; set; } = string.Empty;
        public DateOnly EventDate { get; set; }
        public string CategoryName { get; set; } = string.Empty;
        public string FinishTime { get; set; } = string.Empty;
        public string Position { get; set; } = string.Empty;
        public string TotalFinishers { get; set; } = string.Empty;
        public string Status { get; set; } = "Finished";
    }

    public class ParticipantProfileViewModel
    {
        public string UserID { get; set; } = string.Empty;
        public string FullName { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public string PhoneNumber { get; set; } = string.Empty;
        public string? ProfilePictureUrl { get; set; }
        public IFormFile? ProfilePicture { get; set; }
    }
}
