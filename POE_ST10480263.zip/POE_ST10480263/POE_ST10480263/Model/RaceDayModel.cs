﻿namespace RaceDayModel.Models
{
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;

    namespace RaceDayModel
    {
        public class Users
        {
            [Key]
            public string UserID { get; set; } = string.Empty;
            public string FullName { get; set; } = string.Empty;
            public string Email { get; set; } = string.Empty;
            public string Password { get; set; } = string.Empty;
            public string Role { get; set; } = string.Empty;
            public string? PhoneNumber { get; set; }

            [NotMapped] 
            public string? ProfilePictureUrl { get; set; }
        }
    }

    public class Venue
    {
        public string VenueID { get; set; } = Guid.NewGuid().ToString();
        public string VenueName { get; set; } = string.Empty;
        public string City { get; set; } = string.Empty;
        public string Province { get; set; } = string.Empty;
    }

    public class Events
    {
        public string EventID { get; set; } = Guid.NewGuid().ToString();
        public string OrganiserID { get; set; } = string.Empty;
        public string? VenueID { get; set; }
        public string EventName { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty; // Added for Req 3
        public string Location { get; set; } = string.Empty;    // Added for Req 3
        public string Distance { get; set; } = string.Empty;    // Added for Req 3
        public string EventType { get; set; } = string.Empty;
        public DateOnly EventDate { get; set; }
        public string? BannerImageUrl { get; set; }             // Added for Azure Blob (Req 5)
    }

    public class Categories
    {
        public string CategoryID { get; set; } = Guid.NewGuid().ToString();
        public string EventID { get; set; } = string.Empty;
        public string CategoryName { get; set; } = string.Empty;
        public string Distance { get; set; } = string.Empty;
        public string Country { get; set; } = string.Empty;
    }

    public class Enrolments
    {
        public string EnrolmentID { get; set; } = Guid.NewGuid().ToString();
        public string ParticipantID { get; set; } = string.Empty;
        public string EventID { get; set; } = string.Empty;       // Added to track event directly
        public string CategoryID { get; set; } = string.Empty;
        public DateOnly RegistrationDate { get; set; } = DateOnly.FromDateTime(DateTime.Today);
        public string Status { get; set; } = "Confirmed";       // Added for Req 7: "Confirmed", "Pending"
    }

    public class Results
    {
        public string ResultsID { get; set; } = Guid.NewGuid().ToString();
        public string EnrolmentID { get; set; } = string.Empty;
        public string FinishTime { get; set; } = string.Empty;   // String (e.g. "01:24:10") is easier to handle
        public string Position { get; set; } = string.Empty;     // e.g. "47"
        public string TotalFinishers { get; set; } = string.Empty; // e.g. "312" for "47th out of 312"
        public string Status { get; set; } = "Finished";
    }

    public class Login
    {
        public string Email { get; set; } = string.Empty;
        public string Password { get; set; } = string.Empty;
    }

    public class UpdateProfileRequest
    {
        public string Phone { get; set; } = string.Empty;
        public string? EmergencyContact { get; set; }
    }

    public class EnrolmentRequest
    {
        public string EventID { get; set; } = string.Empty;
        public string CategoryID { get; set; } = string.Empty;
    }

    // DTO for Organiser Dashboard (Requirement 3)
    public class OrganiserDashboardDto
    {
        public int TotalEvents { get; set; }
        public int TotalEnrolments { get; set; }
        public List<Events> UpcomingEvents { get; set; } = new();
    }
}